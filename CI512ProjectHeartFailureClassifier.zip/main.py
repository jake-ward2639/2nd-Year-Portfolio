from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn import preprocessing
import pandas as pd


pd_df = pd.read_csv("heart.csv", skiprows=0)
print(pd_df)
pd_df.info(); print()
for col in pd_df.columns:
  print(f'{col} has {pd_df[col].nunique()} unique values.');
print()

le = preprocessing.LabelEncoder()
change_column=['Sex','ChestPainType','RestingECG','ExerciseAngina','ST_Slope']
for i in change_column:
  pd_df[i]= le.fit_transform(pd_df[i])

clf1 = KNeighborsClassifier(n_neighbors=3) # KNN classifier/method
clf2 = DecisionTreeClassifier() # Desition Tree classifier/method
clf3 = RandomForestClassifier(max_depth=4) # Random Forest classifier/method

X = pd_df.values[:, 0:10] # 0:... 1 less than Y
Y = pd_df.values[:,11] # 1 less than columns (the final column we're classifying)
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.3) # 70/30

estimators = [
  ('knn', clf1), ('dt', clf2), ('rf', clf3)
]
clf4 = StackingClassifier(
  estimators=estimators, final_estimator=MLPClassifier(max_iter=300)
)
clf4 = clf4.fit(X_train, Y_train) # train using estimators on contents of X and Y training data
Y_prediction = clf4.predict(X_test) # predict Y in test sample using X in test sample
print("Stacking Classifier Train/test accuracy:",accuracy_score(Y_test,Y_prediction))
print("Stacking Classifier Train/test precision:",precision_score(Y_test,Y_prediction, average="macro"))

from sklearn.model_selection import ShuffleSplit
cv = ShuffleSplit(n_splits=5, test_size=0.3)

from sklearn.model_selection import cross_val_score # cross validation
scores = cross_val_score(clf4, X, Y, cv=cv);print()
print("Cross fold validation scores:",scores)
print("Cross fold validation mean score:",scores.mean())