<?php
    
    Class textMessages{
        
        private $database = null;
        private $statuscode = '';
        private $data = '';
        
        function __construct() {
            $this->database = new mysqli('localhost', 'jw1448_admin2', '0,.68KbCHFLM', 'jw1448_assignment2Database');
            if(!$this->database)  
           {  
                $this->statuscode = 500;  
           }
        }
        function __destruct() {
            $this->database->close();
        }
        
        private function isUserInvalid($user){
            $len = strlen($user);
            
            if ($len<4 or $len>32){
                return true;
            }
            for ($i = 0; $i < $len; $i++){
                $char = $user[$i];
                if (!(is_numeric($char) or ctype_alpha($char))){
                    return true;
                }
            }
        }

        private function postRequest(){
            if(isset($_POST['to'])&&isset($_POST['from'])&&isset($_POST['message'])){
                
                $toP = $_POST['to'];
                $fromP = $_POST['from'];
                $message = urldecode($_POST['message']);
                
                if ($this->isUserInvalid($toP) == true or $this->isUserInvalid($fromP) == true){
                    $this->statuscode = 400;  
                }else{
                
                    if($database->connect_error == null){
                        
                        $toP = $this->database->real_escape_string($toP);
                        $fromP = $this->database->real_escape_string($fromP);
                        $message = $this->database->real_escape_string($message);
                    
                        $sql = "INSERT INTO messages (`to`, `from`, message)"
                        	     . "VALUES ('$toP','$fromP','$message')";
                        	
                        $success = $this->database->query($sql);
                        if($success){
                        	    
                        	$id = $this->database->insert_id;
                        	$this->statuscode = 201;
                        	$this->data = "{ \"id\" : $id}";
                        		
                        }else{
                            	    
                            $this->statuscode = 400;  
                            		
                        }
                        	
                    }else{
                        
                        $this->statuscode = 500;  
                        	
                    }
                }
            }else{
                $this->statuscode = 400;
            }
        }
        
        private function getRequest(){
            $userSearch;
            $column;
            $otherColumn;
            if(isset($_GET['from'])){
                
                $userSearch = $_GET['from'];
                $column = "from";
                $otherColumn = "to";
                
            }elseif(isset($_GET['to'])){
                
                $userSearch = $_GET['to'];
                $column = "to";
                $otherColumn = "from";
                
            }else{
                $this->statuscode = 400;
                return;
            }
            
            if ($this->isUserInvalid($userSearch) == true){
                $this->statuscode = 400;
            }else{
            
                if($database->connect_error == null){
                    
                    $userSearch = $this->database->real_escape_string($userSearch);
                    
                    $sql = "SELECT id, `" . $otherColumn . "`, message FROM messages WHERE `" . $column . "` = '" . $userSearch . "'";

                    $result = $this->database->query($sql);
                    $rows = array();
                    while($r = mysqli_fetch_assoc($result)) {
                        $rows[] = $r;
                    }
                    if (empty($rows)){
                        $this->statuscode = 204;  
                    }else{
                        $this->statuscode = 200;
                        $this->data = "{\"" . $column . "\":\"" . $userSearch . "\",\"messages\" : " . json_encode($rows) . "}";
                    }
                
                } else {
                    $this->statuscode = 500;  
                }
            }
        }
        
        public function handleRequest(){
            
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                
                $this->postRequest();
                
            }elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
                
                $this->getRequest();
                
            }else{
                
                $this->statuscode = 405;  
            }
            http_response_code($this->statuscode);
            if ($this->statuscode == 200 || $this->statuscode == 201){
                header('content-type: application/json');
                echo $this->data;
            }
        }
    }

    
    
    $textMessagesApi = new textMessages();
    $textMessagesApi->handleRequest();
?>